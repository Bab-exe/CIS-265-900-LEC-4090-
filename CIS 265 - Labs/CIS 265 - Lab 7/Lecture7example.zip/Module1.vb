﻿Imports System
Imports System.Data

Module Module1
    Sub Main(args As String())

        'Create a database connection called Connection
        Dim con As OleDb.OleDbConnection
        'Create a command
        Dim cmd As New OleDb.OleDbCommand
        'Create a data adapter
        Dim da As New OleDb.OleDbDataAdapter
        'Create a new data table
        Dim dt As New DataTable


        'Make sure the database file is saved inside your bin\Debug directory!!!

        'MDB (32 bit) connection string:
        con = New OleDb.OleDbConnection("Data Source=LectureDB.mdb; Provider=Microsoft.Jet.OLEDB.4.0")


        'ACCDB (64bit) connection string:
        'con = New OleDb.OleDbConnection("Data Source=LectureDB.accdb; Provider=Microsoft.ACE.OLEDB.12.0")


        con.Open()  'open up a connection to the database
        cmd.Connection = con

        'Create a new command to select all company names from the customers table
        da.SelectCommand = New OleDb.OleDbCommand("SELECT CompanyName FROM Customers", con)

        'Fill the data table with the above command
        da.Fill(dt)

        'Close the connection!!!
        con.Close()

        For Each row As DataRow In dt.Rows
            Console.WriteLine(row("CompanyName").ToString())
        Next


        Console.ReadLine()

    End Sub
End Module
