﻿
Imports System.Data
Imports System.Data.OleDb
Imports System.Security.Cryptography

Public Module Device_Database

    Private Connection As OleDb.OleDbConnection



    '64 bit by default
    Sub DB_Connect(DataSource As String, Optional Provider As String = "Microsoft.ACE.OLEDB.12.0")

        Dim constr = $"Data Source={DataSource}; Provider={Provider};"

        Connection = New OleDb.OleDbConnection(constr)



    End Sub



    'Inputs a device into the database




    Sub Generate_Devices(Count As UShort, Optional Clear_Table As Boolean = False)

        If Clear_Table Then
            'Clear_Devices()
        End If
        Dim queryname As String = "INPUT_Device"

        Dim DeviceType As Integer
        Dim Brand As Integer
        Dim OS As Integer
        Dim IP As String
        Dim MAC As String

        Connection.Open()
        Using command As New OleDbCommand(queryname, Connection)
            command.CommandType = CommandType.StoredProcedure



            For i = 1 To Count Step 1
                Brand = A_Device.Brand_Index()
                DeviceType = A_Device.DeviceType_Index()
                OS = A_Device.OS_Index()
                IP = A_Device.IP_Address()
                MAC = A_Device.MAC_Address()

                command.Parameters.AddWithValue("@Brand_ID", Brand)
                command.Parameters.AddWithValue("@DeviceType_ID", DeviceType)
                command.Parameters.AddWithValue("@OS_ID", OS)
                command.Parameters.AddWithValue("@IP_Address", IP)
                command.Parameters.AddWithValue("@MAC_Address", MAC)

                command.ExecuteNonQuery()
            Next



        End Using

        Connection.Close()
    End Sub



    'probably wont use'
    Private Sub Clear_Devices()
        Dim queryname = "CLEAR_Devices"

        Connection.Open()
        Using command As New OleDb.OleDbCommand(queryname, Connection)
            command.CommandType = CommandType.StoredProcedure
            command.ExecuteNonQuery()
        End Using
        Connection.Close()
    End Sub

    Private Function READ(Of T)(queryname As String, fieldname As String) As List(Of T)

        Dim list As New List(Of T)

        Connection.Open()
        Using command As New OleDb.OleDbCommand(queryname, Connection)
            command.CommandType = CommandType.StoredProcedure

            Using reader As OleDbDataReader = command.ExecuteReader()
                While reader.Read()

                    list.Add(reader(fieldname))
                End While
            End Using

        End Using
        Connection.Close()

        Return list

    End Function

    Function get_Brands() As List(Of String)
        Dim queryname = "OUTPUT_Brands"
        Dim fieldname = "Brand_Name"
        Dim brands As New List(Of String)

        Return READ(Of String)(queryname, fieldname)
        Connection.Close()
    End Function


    'todo
    Function get_DeviceTypes() As List(Of String)
        Dim queryname = "OUTPUT_DeviceTypes"
        Dim deviceTypes As New List(Of String)

        Connection.Open()
        Using command As New OleDb.OleDbCommand(queryname, Connection)
            command.CommandType = CommandType.StoredProcedure

            Using reader As OleDbDataReader = command.ExecuteReader()
                While reader.Read()

                    deviceTypes.Add(reader("DeviceName"))
                End While
            End Using

        End Using
        Connection.Close()

        Return deviceTypes
    End Function


    'gets the device type based on the ID directly from database
    Function get_DeviceType(ID As Integer) As String

        Dim queryname = "OUTPUT_DeviceType"
        Dim fieldname = "DeviceName"

        Dim deviceType As String = ""
        Connection.Open()
        Using command As New OleDb.OleDbCommand(queryname, Connection)
            command.CommandType = CommandType.StoredProcedure
            command.Parameters.AddWithValue("@ID", ID)

            Using reader As OleDbDataReader = command.ExecuteReader()
                While reader.Read()

                    deviceType = reader(fieldname)
                End While
            End Using

        End Using

        Return deviceType



    End Function

    Function get_OpSys() As List(Of String)
        Dim queryname = "OUTPUT_OpSys"
        Dim fieldname = "OS_Name"
        Dim OS As New List(Of String)

        Return READ(Of String)(queryname, fieldname)

    End Function

    Sub Test()
        Connection.Open()
        Connection.Close()
    End Sub










End Module








