﻿


Module A_Device
    Private ReadOnly Random As New Random()

    'will probably be useful later
    Public ReadOnly Brand_List = Device_Database.get_Brands()
    Public ReadOnly DeviceType_List = Device_Database.get_DeviceTypes()
    Public ReadOnly Os_List = Device_Database.get_OpSys()

    'generates ip address
    Function IP_Address() As String

        Return $"{Random.Next(0, 255 + 1)}.{Random.Next(0, 255 + 1)}.{Random.Next(0, 255 + 1)}.{Random.Next(0, 255 + 1)}"
    End Function

    'generates mac address
    Function MAC_Address() As String
        Dim Mac As String = ""
        Dim generated_number As UShort


        'mac address
        For i = 1 To 6
            generated_number = Random.Next(0, 15 + 1)

            Select Case generated_number
                Case 10
                    Mac &= "A"

                Case 11
                    Mac &= "B"

                Case 12
                    Mac &= "C"

                Case 13
                    Mac &= "D"

                Case 14
                    Mac &= "E"

                Case 15
                    Mac &= "F"

                Case Else
                    Mac &= generated_number
            End Select

            Mac &= Random.Next(0, 9 + 1)

            'no colon at the end
            If i <> 6 Then
                Mac &= ":"

            End If
        Next

        Return Mac

    End Function

    'Generates a Brand_Index 
    Function Brand_Index() As Integer

        Return Random.Next(0, Brand_List.Count)
    End Function

    'Generates a DeviceType_Index
    Function DeviceType_Index() As Integer

        Return Random.Next(0, DeviceType_List.Count)
    End Function

    'Generates a OS_Index
    Function OS_Index() As Byte
        Return Random.Next(0, Os_List.Count)
    End Function






End Module
